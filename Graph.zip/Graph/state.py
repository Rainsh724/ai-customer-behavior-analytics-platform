# PATH: app/graph/state.py

"""
ساختار state برای معماری Agent + Tools.

conversation_context عمداً جدا از messages نگه داشته می‌شود.
messages برای تاریخچه‌ی مکالمه و نتایج ابزارهاست؛
conversation_context برای context فعال همین مکالمه است.

این جداسازی باعث می‌شود Follow-upهایی مثل:
    «چرا؟»
    «دلیلش؟»
    «همون محصول؟»
بدون اتکا به حدس LLM به context قبلی متصل شوند.
"""

from __future__ import annotations

from typing import Annotated, Any, TypedDict
from operator import add


class GraphState(TypedDict, total=False):

    # ============================================================
    # تاریخچه‌ی مکالمه
    # ============================================================

    messages: Annotated[list[dict[str, Any]], add]

    # ============================================================
    # Context فعال مکالمه
    #
    # این فیلد توسط main.py به‌صورت deterministic ساخته می‌شود.
    #
    # نمونه:
    # {
    #     "is_follow_up": True,
    #     "product_id": 158423,
    #     "product_title": "...",
    #     "metric": "units_sold",
    #     "metric_label": "تعداد خرید",
    #     "period_start": "2022-09-01",
    #     "period_end": "2023-03-01",
    #     "period_label": "شش ماه اخیر",
    #     "previous_result": {...}
    # }
    #
    # این context نباید توسط LLM حدس زده شود.
    # ============================================================

    conversation_context: dict[str, Any]

    # ============================================================
    # تشخیص سوال چندبخشی (Multi-question splitting)
    #
    # detect_multi_question_node (nodes.py) این دو فیلد رو پر می‌کنه:
    # - is_multi_question: آیا سوال کاربر واقعاً چند بخش مستقل داره؟
    # - sub_questions: لیست بخش‌های تفکیک‌شده (فقط وقتی is_multi_question
    #   True باشه پر می‌شه؛ در غیر این صورت خالیه و مسیر عادی agent
    #   دست‌نخورده اجرا می‌شه).
    #
    # هدف: سوالات چندبخشی به‌جای اینکه در یک حلقه‌ی طولانی
    # agent<->tools (با تاریخچه‌ی رو‌به‌رشد) پردازش بشن -- که مصرف توکن
    # رو بالا می‌بره و باعث رسیدن زودهنگام به سقف/متوقف شدن وسط کار
    # می‌شه -- هر بخش با یک context مستقل و کوچیک (نه کل تاریخچه)
    # پردازش می‌شه.
    # ============================================================

    is_multi_question: bool

    sub_questions: list[str]

    # ============================================================
    # وضعیت پردازش سوالات چندبخشی
    # ============================================================

    current_sub_question_index: int

    current_sub_question: str

    sub_question_messages: list[dict[str, Any]]

    sub_question_answers: Annotated[
        list[dict[str, Any]],
        add,
    ]

    sub_question_tool_trace: list[dict[str, Any]]
    
    sub_question_iterations: int

    sub_question_consecutive_tool_errors: int

    sub_question_correction_attempts: int

    sub_question_validation: dict[str, Any]

    # ============================================================
    # شمارنده‌ی دور Agent <-> Tools
    # ============================================================

    iterations: int

    # ============================================================
    # شمارنده‌ی خطاهای متوالی ابزارها
    # ============================================================

    consecutive_tool_errors: int

    # ============================================================
    # رد ابزارها برای validation / audit
    # ============================================================

    tool_trace: Annotated[list[dict[str, Any]], add]

    # ============================================================
    # پاسخ نهایی
    # ============================================================

    final_answer: str

    # ============================================================
    # نتیجه‌ی validation
    # ============================================================

    validation: dict[str, Any]

    # ============================================================
    # شمارنده‌ی تلاش‌های واقعیِ اصلاح (برگشت به Agent، نه فقط
    # بازنویسیِ متنیِ correct_answer). با رسیدن به MAX_CORRECTION_RETRIES
    # (در nodes.py) دیگه به "agent" برنمی‌گردیم و فقط correct_answer
    # (بازنویسیِ متنیِ یک‌باره) اجرا می‌شه.
    # ============================================================

    correction_attempts: int

    # ============================================================
    # فیدبک ممیزی که قراره یک‌بار (در همون دور بعدی) به Agent داده بشه
    # -- توسط prepare_retry_node پر می‌شه و در agent_node به‌صورت یک
    # پیام system موقت (جزو turn_control_messages) به مدل تزریق می‌شه.
    # ============================================================

    retry_feedback: dict[str, Any]

    # ============================================================
    # خطاها
    # ============================================================

    errors: Annotated[list[str], add]