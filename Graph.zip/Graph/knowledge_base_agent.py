## PATH: app/graph/knowledge_base_agent.py
"""
اسکلتِ Tool_KnowledgeBase -- هنوز پیاده‌سازی نشده، منتظر سند/محتوای
آموزشی و پیاده‌سازی توسط توسعه‌دهنده‌ی دیگر.

این چیه؟
---------
یک لایه‌ی RAG جدا از tool_rag (که روی نظرات مشتری‌ها سرچ می‌کنه). این
یکی قراره روی یک پایگاه‌دانش آموزشی سرچ کنه -- محتوایی درباره‌ی «چطور
باید پیشنهاد مدیریتی داد» (چارچوب‌ها، اصول، الگوهای تحلیل کسب‌وکار).
هدف اینه که Agent قبل از دادن هر پیشنهاد مدیریتی، اول این دانش رو
بخونه، و پیشنهادش رو با ترکیب این دانش + دانش عمومی خودش بسازه -- نه
فقط از حافظه‌ی پیش‌آموزش‌دیده‌ی خودِ مدل.

وضعیت فعلی: غیرفعال و کامنت‌شده در همه‌جا.
---------------------------------------------
تا وقتی محتوای پایگاه‌دانش آماده نشده و کد واقعی جست‌وجو (توسط توسعه‌دهنده‌ی
دیگر) نوشته نشده، این ابزار در جاهای زیر عمداً کامنت شده -- یعنی Agent
اصلاً نمی‌دونه این ابزار وجود داره و امتحانش نمی‌کنه:
    1. اینجا (knowledge_base_agent.py) -- فقط اسکلت/امضای تابع، بدنه
       واقعی TODO است.
    2. tools.py -- هم TOOL_DEFINITIONS و هم شاخه‌ی dispatcher برای
       "tool_knowledge_base" کامنت شده.
    3. main.py::AGENT_SYSTEM_PROMPT -- قانونِ "قبل از پیشنهاد مدیریتی،
       اول این ابزار رو صدا بزن" به‌صورت یک بلوک کامنت جدا نگه داشته شده
       (چون اگه در پرامپت زنده باشه ولی ابزار در TOOL_DEFINITIONS نباشه،
       مدل سعی می‌کنه ابزاری رو صدا بزنه که وجود نداره -> خطا).

نحوه‌ی فعال‌سازی (وقتی سند/کد آماده شد):
------------------------------------------
    الف) بدنه‌ی run_knowledge_base_tool پایین رو با پیاده‌سازی واقعی
         (embed_text از llm_client.py + جست‌وجوی برداری روی جدول
         پایگاه‌دانش -- دقیقاً همون الگوی run_rag_tool در
         vector_retriever.py) جایگزین کن.
    ب) در tools.py، بلوک کامنت‌شده‌ی مربوط به "tool_knowledge_base" رو
       از حالت کامنت خارج کن (هم در TOOL_DEFINITIONS هم در
       execute_tool_call).
    ج) در main.py، بلوک کامنت‌شده‌ی قانون مربوطه رو به AGENT_SYSTEM_PROMPT
       اضافه کن (از حالت کامنت خارج کن).

پیشنهاد شکل جدول (برای هماهنگی با توسعه‌دهنده‌ی دیگر -- نهایی نیست):
    knowledge_base_embedding(
        id BIGINT PK,
        content TEXT,              -- متن آموزشی خام
        source TEXT,                -- منبع/فصل/سند مرجع
        embedding VECTOR(768)       -- با همون مدل embed_text در llm_client.py
    )
"""
from __future__ import annotations

import logging
from typing import Any

from .llm_client import call_llm_json

logger = logging.getLogger(__name__)


def run_knowledge_base_tool(query: str) -> dict[str, Any]:
    """
    ورودی: query -- موضوع/سوالی که Agent می‌خواد قبل از دادن پیشنهاد
    مدیریتی، در پایگاه‌دانش آموزشی جست‌وجو کنه.
    خروجی (انتظار می‌ره): خلاصه‌ای از مرتبط‌ترین بخش‌های محتوای آموزشی
    (شبیه خروجی run_rag_tool -- مثلاً چند قطعه‌ی نماینده + منبع هرکدوم).

    TODO (توسعه‌دهنده‌ی دیگر): جایگزین کردن این بدنه با جست‌وجوی برداری
    واقعی روی جدول پایگاه‌دانش (نگاه کن به توضیحات بالای فایل برای الگو
    و شکل پیشنهادی جدول). تا اون‌موقع، این تابع اصلاً از هیچ‌جای گراف
    صدا زده نمی‌شه (چون در tools.py کامنت شده) -- این خطا فقط یک محافظ
    اضافیه، برای وقتی که کسی به‌اشتباه مستقیم و زودتر از موعد صداش بزنه.
    """
    raise NotImplementedError(
        "run_knowledge_base_tool هنوز پیاده‌سازی نشده -- منتظر محتوای "
        "پایگاه‌دانش و کد جست‌وجوی توسط توسعه‌دهنده‌ی دیگر."
    )


# ============================================================
# پلیس‌هولدر موقت -- جدا از run_knowledge_base_tool بالا.
# ============================================================
# هدف: تا وقتی جدول knowledge_base_embedding و جست‌وجوی برداری واقعی
# (توسط بقیه‌ی اعضا) آماده بشه، Agent موقع نیاز به توصیه‌ی مدیریتی
# دست‌خالی نمونه. قبلاً این تابع یک خلاصه‌ی ثابت و کلی (صرف‌نظر از
# query) برمی‌گردوند که عملاً هیچ ارتباطی با سوال واقعی کاربر نداشت.
#
# الان به‌جاش مستقیم از خودِ LLM (call_llm_json -- همون wrapper ساده‌ای
# که در audit.py/nodes.py هم استفاده می‌شه) می‌خوایم بر اساس دانش عمومی
# خودش (چارچوب‌های تحلیل کسب‌وکار/مدیریت فروشگاه آنلاین -- نه دانش
# اختصاصی این پروژه) یک خلاصه‌ی *مرتبط با همون query* بسازه. این هنوز
# RAG واقعی روی سند آموزشی داخلی نیست -- فقط دانش عمومی مدله -- ولی
# برخلاف نسخه‌ی قبلی، واقعاً به موضوعی که Agent پرسیده مرتبطه.
#
# نحوه‌ی سواپ کردن با نسخه‌ی واقعی وقتی آماده شد:
#   در tools.py::execute_tool_call، فراخوانی
#   run_knowledge_base_tool_debug_placeholder را با run_knowledge_base_tool
#   (نسخه‌ی بالا) عوض کن -- امضای هر دو یکسانه (query: str) -> dict.
# ============================================================

_KB_PLACEHOLDER_SYSTEM_PROMPT = """
You are standing in for a real training knowledge base (not ready yet).
Based only on your own general knowledge of business-analysis
principles/frameworks and online-store management (not any data specific
to this store -- that must only come from SQL/RAG), produce a short,
practical summary directly relevant to the topic of the query below.
 
Return only a JSON object in this format -- write no extra text:
 
{"summary": "<a concise, practical Persian summary>"}
 
Rules:
- Only write general managerial frameworks/principles relevant to the
  query's topic -- never invent any number, product/brand name, or
  specific result of your own; those must come from this conversation's
  real SQL/RAG, not from this summary.
- If the query is completely outside the scope of business/online-store
  analysis, say in one sentence that this knowledge base has nothing for
  this topic.
- The output must be Persian, fluent, and short (a few sentences to a few
  short paragraphs) -- not a full article.
"""


def run_knowledge_base_tool_debug_placeholder(query: str) -> dict[str, Any]:
    """
    ورودی: query -- همون موضوعی که Agent قبل از دادن پیشنهاد مدیریتی
    می‌خواد "در پایگاه‌دانش" جست‌وجو کنه.
    خروجی: dict با کلید "summary" -- تا وقتی RAG واقعی آماده بشه، این
    خلاصه از دانش عمومی خودِ LLM (نه یک سند ثابت) تولید می‌شه.

    fail-open: اگه تماس LLM شکست بخوره، به‌جای ترکوندن کل نود tools
    (که داخل safe_node گیر می‌افته و خطای غیرمرتبط با این یک ابزار
    باعث از دست رفتن جواب کل دور می‌شه)، یک خلاصه‌ی خیلی کلی/عمومی
    fallback برمی‌گردونیم تا Agent همچنان بتونه بدون این ابزار هم به
    کارش ادامه بده.
    """
    try:
        result = call_llm_json(_KB_PLACEHOLDER_SYSTEM_PROMPT, query)
        summary = result.get("summary") if isinstance(result, dict) else None
        summary = str(summary).strip() if summary else ""
    except Exception as exc:  # noqa: BLE001 - این ابزار نباید کل دور رو خراب کنه
        logger.warning(
            "run_knowledge_base_tool_debug_placeholder: تماس LLM شکست خورد: %s",
            exc,
        )
        summary = ""

    if not summary:
        summary = (
           "The training knowledge base isn't ready yet, and generating a "
           "summary for this specific topic wasn't possible either -- "
           "build the suggestion only on your own general knowledge and "
           "the SQL/RAG evidence from this conversation."

        )

    return {
        "query": query,
        "source": (
           "DEBUG_PLACEHOLDER -- generated from the LLM's general "
           "knowledge, not from a real training document; not yet "
           "replaced by the real version"
        ),
        "summary": summary,
    }
